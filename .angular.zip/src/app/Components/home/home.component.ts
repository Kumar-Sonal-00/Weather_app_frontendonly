import { Component } from '@angular/core';
import { AuthService } from '../../Services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  constructor(private authService: AuthService, private router: Router) {}

  // Logic to handle redirection based on authentication
  navigateHome() {
    if (this.authService.isUserLoggedIn()) {
      this.router.navigate(['/profile']); // Redirect to profile if logged in
    } else {
      this.router.navigate(['/home']); // Redirect to home if not logged in
    }
  }

}
