import { Component } from '@angular/core';
import { AuthService } from '../../Services/auth.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {
  email: string | null = '';

  constructor(private authService: AuthService) {
    this.email = this.authService.getCurrentUserEmail();  // Fetch logged-in user's email
  }
}
