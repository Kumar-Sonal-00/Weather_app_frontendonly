import { Routes } from '@angular/router';
import { LoginComponent } from './Components/login/login.component';
import { RegisterComponent } from './Components/register/register.component';
import { HomeComponent } from './Components/home/home.component';
import { FavouriteComponent} from './Components/favourite/favourite.component';
import { WeatherForcastingComponent } from './Components/weather-forcasting/weather-forcasting.component';

// Define your application's routes
export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'home', component: HomeComponent},
  { path: 'favorites', component: FavouriteComponent},
  { path: 'weather-forecast', component: WeatherForcastingComponent},
  { path: '**', redirectTo: '/home' }  
];