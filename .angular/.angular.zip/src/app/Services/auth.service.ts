import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Router } from '@angular/router';
 
@Injectable({
  providedIn: 'root',
})
export class AuthService implements OnInit {
  private apiUrl = 'http://localhost:3000/users';
  private isLoggedIn = false;
  private currentUser: any;
 
  constructor(private http: HttpClient, private router: Router) {
  }
  ngOnInit(): void {
    this.isLoggedIn = localStorage.getItem('isLoggedIn') ? true : false;
  }
 
  getLoggedIn(): boolean{
    return this.isLoggedIn;
  }
  login(username: string, password: string) {
    return this.http
      .get(`${this.apiUrl}?username=${username}&password=${password}`)
      .subscribe((users: any) => {
        if (users.length > 0) {
          this.isLoggedIn = true;
          this.currentUser = users[0];
          localStorage.setItem('isLoggedIn', 'true');
          localStorage.setItem('userId', this.currentUser.id);
          this.router.navigate(['/']);
        } else {
          alert('Invalid username or password');
        }
      });
  }
 
  register(username: string, password: string) {
    return this.http.post(this.apiUrl, { username, password });
  }
 
  logout() {
    this.isLoggedIn = false;
    this.currentUser = null;
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userId');
    this.router.navigate(['/login']);
  }
 
  isUserLoggedIn() {
    return localStorage.getItem('isLoggedIn') === 'true';
  }
 
  getCurrentUserId() {
    return localStorage.getItem('userId');
  }
}
