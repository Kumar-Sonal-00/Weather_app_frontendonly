import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-register',
  standalone: true,
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  imports: [CommonModule, FormsModule]
})
export class RegisterComponent {
  registerData = { username: '', password: '', confirmPassword: '' };
  errorMessage: string | null = null;

  constructor(private http: HttpClient, private router: Router) {}

  onRegister() {
    // Check if passwords match
    if (this.registerData.password !== this.registerData.confirmPassword) {
      this.errorMessage = 'Passwords do not match';
      return;
    }

    const usernameCheckUrl = `http://localhost:3000/users?username=${this.registerData.username}`;
    const registerUrl = 'http://localhost:3000/users'; 

    // Check if the username already exists
    this.http.get<any[]>(usernameCheckUrl).subscribe(
      existingUsers => {
        if (existingUsers.length > 0) {
          this.errorMessage = 'Username already exists';
          return;
        }

        // If the username doesn't exist, proceed with registration
        this.http.post<any>(registerUrl, this.registerData)
          .subscribe(
            response => {
              this.router.navigate(['/login']); 
            },
            error => {
              this.errorMessage = 'An error occurred during registration';
            }
          );
      },
      error => {
        this.errorMessage = 'An error occurred while checking username availability';
      }
    );
  }
}