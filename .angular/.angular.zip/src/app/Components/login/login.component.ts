import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  imports: [CommonModule, FormsModule]
})
export class LoginComponent {
  loginData = { username: '', password: '' };
  errorMessage: string | null = null;

  constructor(private http: HttpClient, private router: Router) {}

  onLogin() {
    const loginUrl = 'http://localhost:3000/users'; 

    // Fetch all users to check if the user exists
    this.http.get<any[]>(loginUrl).subscribe(
      users => {
        const user = users.find(u => u.username === this.loginData.username);
        
        if (!user) {
          this.errorMessage = 'User not found';
          return;
        }

        // Check if the password matches
        if (user.password !== this.loginData.password) {
          this.errorMessage = 'Invalid username or password';
          return;
        }

        // Successful login
        localStorage.setItem('token', user.token); // Adjust as necessary if your user object has a token
        this.router.navigate(['/home']); 
      },
      error => {
        this.errorMessage = 'An error occurred while logging in';
      }
    );
  }
}