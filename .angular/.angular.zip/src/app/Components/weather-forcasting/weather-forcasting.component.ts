import { CommonModule } from '@angular/common';
import { Component, OnInit,Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { catchError, Observable, of } from 'rxjs';
import { WeatherForcastService } from '../../Services/weather-forcast.service';
import { FavouriteService } from '../../Services/favourite.service';
import { Router } from '@angular/router';
 
@Component({
  selector: 'app-weather-forcasting',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatSnackBarModule,
    MatGridListModule,
    MatFormFieldModule,
    FormsModule,
  ],
  templateUrl: './weather-forcasting.component.html',
  styleUrl: './weather-forcasting.component.css',
})
export class WeatherForcastingComponent implements OnInit {
  weatherData$: Observable<any> = of([]);
  error: string | null = null;
  // city = 'London'; 
  searchedCity: string = '';
  @Input() city: string = 'Pune';
  @Input() callingFromParent:boolean=false;
  constructor(
    private weatherService: WeatherForcastService,
    private favoritesService: FavouriteService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}
 
  ngOnInit(): void {
    this.fetchWeather();
  }
 
  fetchWeather(): void {
    this.weatherData$ = this.weatherService.getWeatherByCity(this.city).pipe(
      catchError((error) => {
        this.error = 'City not found';
        this.snackBar.open(this.error, 'Close', { duration: 3000 });
        return of(null);
      })
    );
  }
 
  searchWeather(): void {
    if (this.searchedCity.trim()) {
      this.city = this.searchedCity;
      this.fetchWeather();
    }
  }
 
  refreshWeather(): void {
    this.fetchWeather();
  }
  addToFavorites(city: string): void {
    this.favoritesService.addToFavorites(city);
    this.snackBar.open(`${city} added to favorites!`, 'Close', { duration: 3000 });
  }
}