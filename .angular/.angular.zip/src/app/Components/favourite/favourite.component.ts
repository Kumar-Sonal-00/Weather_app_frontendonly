 
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component , OnInit} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { FavouriteService } from '../../Services/favourite.service';
import { WeatherForcastService } from '../../Services/weather-forcast.service';
import { WeatherForcastingComponent } from '../weather-forcasting/weather-forcasting.component';
 
@Component({
  selector: 'app-favourite',
  standalone: true,
  imports: [
    CommonModule,
    MatListModule,
    MatButtonModule,
    MatCardModule,
    FormsModule,
    HttpClientModule,
    WeatherForcastingComponent
  ],
  templateUrl: './favourite.component.html',
  styleUrl: './favourite.component.css',
})
 
export class FavouriteComponent implements OnInit {
 
  favoriteCities: string[] = [];
 
  constructor(private weatherService: WeatherForcastService, private favService:FavouriteService) {}
 
  ngOnInit(): void {
    this.getFavoriteCities();
  }
 
  getFavoriteCities(): void {
    this.favService.getFavorites().subscribe(
      (favoriteCities: any[]) => {
        this.favoriteCities = favoriteCities.map(fav => fav.city);
        this.weatherService.setCity(this.favoriteCities);
      },
      error => {
        console.error("Failed to fetch favorite cities:", error);
      }
    );
  }

  removeCity(city: string): void {
    this.favService.removeFromFavorites(city);
    this.favoriteCities = this.favoriteCities.filter(c => c !== city); // Update the list locally
  }
 
  
 
  // favoriteCities: string[] = [];
 
  // constructor(private weatherService: WeatherForcastService) {}
 
  // ngOnInit(): void {
  //   this.favoriteCities = this.weatherService.getFavoriteCities();
  //   console.log('Favorite Cities:', this.favoriteCities);
 
  // }
  // favourites: string[] = [];
  // searchTerm: string = '';
  // favoriteCities: string[] = [];
  // private apiUrl = 'http://localhost:3000/favorites'; // Hardcoded API URL // API endpoint to link with json-server
 
  // constructor(private favouriteService: FavouriteService) {
  //   //this.favourites = this.favouriteService.getFavourites();
  // }
 
  // activeTab: string = 'viewed';
  // cities: { name: string }[] = [
  //   { name: 'Bengaluru' },
  //   { name: 'Mumbai' },
  //   { name: 'Delhi' },
  // ];
 
  // showTab(tabName: string) {
  //   this.activeTab = tabName;
  // }
 
  // removeCity(city: { name: string }) {
  //   this.cities = this.cities.filter((c) => c !== city);
  // }
 
  // onSearch(event: Event) {
  //   const searchTerm = (event.target as HTMLInputElement).value.toLowerCase();
  //   // Implement search functionality here
  // }
 
  // removeFavourite(city: string) {
  //   this.favouriteService.removeFavourite(city);
  //   this.favourites = this.favouriteService.getFavourites(); // Update the list after removal
  // }
 
  // favoriteCities: string[] = [];
  // weatherData$: any[] = [];
 
  // constructor(
  //   private favouriteService: FavouriteService,
  //   private weatherService: WeatherForcastService
  // ) {}
 
  // ngOnInit() {
  //   this.favoriteCities = this.favouriteService.getFavorites();
  //   this.loadWeatherForFavorites();
  // }
 
  // loadWeatherForFavorites() {
  //   this.favoriteCities.forEach(city => {
  //     this.weatherService.getWeatherByCity(city).subscribe(data => {
  //       this.weatherData$.push(data);
  //     });
  //   });
  // }
 
  // removeFromFavorites(city: string) {
  //   this.favouriteService.removeFromFavorites(city);
  //   this.favoriteCities = this.favouriteService.getFavorites();
  //   this.weatherData$ = this.weatherData$.filter(data => data.cityName !== city);
  // }
 
  // favoriteCities: string[] = [];
 
  // Method to remove a city from favorites
  // removeFromFavorites(city: string) {
  //   this.favoriteCities = this.favoriteCities.filter(c => c !== city);
  // }
 
  // ngOnInit() {
  //   this.favoriteCities = JSON.parse(localStorage.getItem('favorites') || '[]');
  // }
 
  // removeCity(city: string) {
  //   this.favoriteCities = this.favoriteCities.filter(favCity => favCity !== city);
  //   localStorage.setItem('favorites', JSON.stringify(this.favoriteCities));
  // }
}